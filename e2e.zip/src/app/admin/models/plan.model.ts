import { Service } from './service.model';
import { Agency } from './agency.model';

export class Plan {
    id?: any;
    name: string;
    description?: string;
    totalvalue?: number;
    discount?: any;
    agency?: any;
    services: Service[];
    code?: string;
    iva?:number;
}
