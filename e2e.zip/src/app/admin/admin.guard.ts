import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  usrmail: any;

  constructor(private authService: AuthService, private router: Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean | UrlTree {
      this.usrmail = localStorage.getItem("userlog");

      const targetUrl: string = state.url;
     if (this.authService.isLoggedIn) {
      if (this.usrmail == 'sistemaacuarioaudiovisual@gmail.com' || this.usrmail == 'ccajacanopy@gmail.com' 
        || this.usrmail == 'cajaactividadacuario@gmail.com' || this.usrmail == 'audiovisualcaja@gmail.com' || this.usrmail == 'cajataquillaacuario@gmail.com') {
          return this.router.parseUrl('/admin/new-sales');

      }
      return true;
      

    } else {
      return this.router.parseUrl('/login');
    }
  }
}
